* * * * *

* minuten            0 – 59

* uur van de dag     0 – 24 

* dag van de maand   1 – 31

* maand van het jaar 1 – 12

* dag van de week    0 – 6 (0 = zondag)